// Рекурсивна функція
function countdown(num) {
    console.log(num); // Вивести поточне значення
    if (num > 0) {
        countdown(num - 1); // Рекурсивний виклик із зменшенням на 1
    }
}

// Виклик функції з аргументом 5
countdown(5);
